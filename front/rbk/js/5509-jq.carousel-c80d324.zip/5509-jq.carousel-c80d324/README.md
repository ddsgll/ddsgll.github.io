# jq.carousel

Simple and customizable carousel.  
Demos and usages are available on [here](http://5509.github.com/jq.carousel/).
